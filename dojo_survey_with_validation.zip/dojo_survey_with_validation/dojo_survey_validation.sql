-- INSERT INTO surveys (name, location, language, comments)
-- VALUES ("Chris", "Online", "Python", "Fupa!")
SELECT * FROM surveys